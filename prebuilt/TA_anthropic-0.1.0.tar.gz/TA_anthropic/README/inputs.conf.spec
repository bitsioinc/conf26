[anthropic_usage://<name>]
account = Account to use for this input.
backfill_days = Days of history to ingest on first run (hourly buckets). (Default: 7)
index = (Default: default)
interval = Time interval of the data input, in seconds. (Default: 300)

[anthropic_cost://<name>]
account = Account to use for this input.
backfill_days = Days of history to ingest on first run (daily buckets). (Default: 30)
index = (Default: default)
interval = Time interval of the data input, in seconds. (Default: 3600)

[anthropic_directory://<name>]
account = Account to use for this input.
index = (Default: default)
interval = Time interval of the data input, in seconds. (Default: 3600)

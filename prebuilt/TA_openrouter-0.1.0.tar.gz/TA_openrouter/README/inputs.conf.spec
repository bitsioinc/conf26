[openrouter_analytics://<name>]
account = 
backfill_days = First run only. Whole number from 1 to 30. (Default: 7)
index = (Default: default)
interval = Seconds between collections. Analytics buckets are hourly. (Default: 3600)

[openrouter_keys://<name>]
account = 
index = (Default: default)
interval = (Default: 3600)
